package com.app.caryard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.fragment.app.Fragment;

import com.google.android.material.snackbar.Snackbar;

public class CarDetailsFragment extends Fragment {
    private EditText carModelEditText;
    private EditText carYearEditText;
    private EditText carColorEditText;
    private EditText carUsageEditText;
    private EditText carPriceEditText;
    private Button saveButton;
    private Car currentCar; // Reference to the currently displayed car

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.car_details_fragment, container, false);

        carModelEditText = view.findViewById(R.id.car_model_edit_text);
        carYearEditText = view.findViewById(R.id.car_year_edit_text);
        carColorEditText = view.findViewById(R.id.car_color_edit_text);
        carUsageEditText = view.findViewById(R.id.car_usage_edit_text);
        carPriceEditText = view.findViewById(R.id.car_price_edit_text);
        saveButton = view.findViewById(R.id.save_button);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String model = carModelEditText.getText().toString().trim();
                String year = carYearEditText.getText().toString().trim();
                String color = carColorEditText.getText().toString().trim();
                String usage = carUsageEditText.getText().toString().trim();
                String price = carPriceEditText.getText().toString().trim();
                if (model.isEmpty() || year.isEmpty() || color.isEmpty() || usage.isEmpty() || price.isEmpty()) {
                    Snackbar.make(view, "Please fill in all fields", Snackbar.LENGTH_SHORT).show();
                } else {
                    // Update car details and save (implementation depends on your data storage method)
                    currentCar.setModel(model);
                    currentCar.setYear(year);
                    currentCar.setColor(color);
                    currentCar.setUsage(usage);
                    currentCar.setPrice(price);

                    // Update adapter with modified car (notifyDataSetChanged or specific method)
                    // (This part depends on your activity/fragment communication)

                    // Clear fields for new car
                    carModelEditText.setText("");
                    carYearEditText.setText("");
                    carColorEditText.setText("");
                    carUsageEditText.setText("");
                    carPriceEditText.setText("");
                }
            }
        });

        // Load car details based on arguments or activity/fragment communication
        Bundle bundle = getArguments();
        if (bundle != null && bundle.containsKey("car")) {
            currentCar = (Car) bundle.getSerializable("car");
            carModelEditText.setText(currentCar.getModel());
            carYearEditText.setText(currentCar.getYear());
            carColorEditText.setText(currentCar.getColor());
            carUsageEditText.setText(currentCar.getUsage());
            carPriceEditText.setText(currentCar.getPrice());
        } else {
            // Handle new car case (clear fields)
            carModelEditText.setText("");
            carYearEditText.setText("");
            carColorEditText.setText("");
            carUsageEditText.setText("");
            carPriceEditText.setText("");
        }

        return view;
    }
}