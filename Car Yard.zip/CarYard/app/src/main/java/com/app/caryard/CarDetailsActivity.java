package com.app.caryard;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;
import java.util.List;

public class CarDetailsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.car_detail_activity);

        ViewPager viewPager = findViewById(R.id.viewpager);

        List<Car> cars = new ArrayList<>();
        Intent intent = getIntent();
        String carDetails = intent.getStringExtra("carDetails");
        if (carDetails == null){
            Car car = new Car("","","","","","");
            cars.add(car);
        }else{
            String[] car = carDetails.split("#");
            cars.add(new Car(car[0], car[1], car[2], car[3], car[4], car[5]));
        }
        CarDetailsAdapter adapter = new CarDetailsAdapter(this, cars);
        viewPager.setAdapter(adapter);
    }
}
